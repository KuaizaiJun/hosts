// ==UserScript==
// @name         百度百科、百度经验、百度贴吧 禁止自动播放视频
// @namespace    http://tampermonkey.net/
// @version      0.5
// @description  百度百科、百度经验、百度贴吧 禁止自动播放视频，视频默认改为暂停。
// @license      BSD-3-Clause
// @author       别问我是谁请叫我雷锋
// @incompatible firefox Firefox出现无效的问题，原因还在调查中（开发者版有时候也是有效的）
// @match        https://baike.baidu.com/*
// @match        https://jingyan.baidu.com/*
// @match        https://tieba.baidu.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    function pauseVideo() {
        document.getElementsByTagName("video")[0].pause();
        document.getElementsByTagName("video")[0].removeEventListener("timeupdate", pauseVideo);
    }


    window.onload = function () {
        if (location.hostname == "baike.baidu.com") {
            document.getElementsByTagName("video")[0].addEventListener("timeupdate", pauseVideo);
        }
        if (location.hostname == "jingyan.baidu.com") {
            document.getElementsByTagName("video")[0].addEventListener("timeupdate", pauseVideo);
        }
        if (location.hostname == "tieba.baidu.com") {
            $(".threadlist_video").on("DOMSubtreeModified", function () {
                for (var x in document.getElementsByTagName("video")) {
                    document.getElementsByTagName("video")[x].addEventListener("timeupdate", pauseVideo);
                }
            });
            try {
                document.getElementsByTagName("video")[0].addEventListener("timeupdate", pauseVideo);
            } catch (err) {

            }
        }
    }
})();
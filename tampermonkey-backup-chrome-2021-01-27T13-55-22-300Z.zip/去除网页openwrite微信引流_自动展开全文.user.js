// ==UserScript==
// @name         去除网页openwrite微信引流_自动展开全文
// @match        *://*/*
// @namespace    http://tampermonkey.net/
// @version      0.4
// @description  去除网页openwrite微信引流_自动展开全文,不需要通过公众号获取验证码。
// @author       Lgyh Z
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.getElementById('container').style='position: relative;height: auto;';
    var tmp = document.getElementById('read-more-mask');
    var parent = tmp.parentElement;
    var removed = parent.removeChild(tmp);
    parent.removeChild(parent.children[0])
    removed === tmp;
})();